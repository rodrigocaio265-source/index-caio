const menuBtn = document.getElementById('menuBtn');
const menuLinks = document.getElementById('menuLinks');

if (menuBtn && menuLinks) {
  menuBtn.addEventListener('click', () => {
    menuLinks.classList.toggle('ativo');
  });
}

const alertaBtn = document.getElementById('alertaBtn');
const mensagemAlerta = document.getElementById('mensagemAlerta');
const tipoRisco = document.getElementById('tipoRisco');

const orientacoes = {
  chuva: {
    titulo: 'Chuva intensa — nível amarelo',
    texto: 'Evite áreas de encosta, acompanhe alertas oficiais e mantenha documentos importantes protegidos.'
  },
  calor: {
    titulo: 'Onda de calor — nível laranja',
    texto: 'Beba água, evite exposição direta ao sol e procure locais ventilados, principalmente entre 10h e 16h.'
  },
  seca: {
    titulo: 'Seca — nível amarelo',
    texto: 'Economize água, reutilize quando possível e priorize o uso consciente dos recursos disponíveis.'
  },
  enchente: {
    titulo: 'Enchente — nível vermelho',
    texto: 'Não atravesse áreas alagadas, desligue a energia em caso de risco e procure um ponto seguro.'
  }
};

if (alertaBtn && mensagemAlerta && tipoRisco) {
  alertaBtn.addEventListener('click', () => {
    const escolha = orientacoes[tipoRisco.value];
    mensagemAlerta.innerHTML = `<strong>${escolha.titulo}</strong><p>${escolha.texto}</p>`;
  });
}

const formRelato = document.getElementById('formRelato');
const retornoRelato = document.getElementById('retornoRelato');

if (formRelato && retornoRelato) {
  formRelato.addEventListener('submit', (evento) => {
    evento.preventDefault();

    const regiao = document.getElementById('regiao').value.trim();
    const risco = document.getElementById('riscoRelato').value;
    const descricao = document.getElementById('descricao').value.trim();

    retornoRelato.innerHTML = `
      <strong>Relato registrado na simulação.</strong><br>
      <b>Região:</b> ${regiao}<br>
      <b>Risco:</b> ${risco}<br>
      <b>Descrição:</b> ${descricao}<br><br>
      Esse recurso representa como a plataforma poderia aproximar moradores, tecnologia e prevenção climática.
    `;

    formRelato.reset();
  });
}
